<?php $__env->startComponent('mail::message'); ?>
# New Application
<?php echo e($message->first_name); ?> <?php echo e($message->last_name); ?>

<br>
<?php $__env->startComponent('mail::table'); ?>
| name | Value |
| -- |--------:|
<?php $__currentLoopData = $message->except('_token'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
| <?php echo e(ucfirst(str_replace('_', ' ', $key))); ?> | <?php echo e($item); ?>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php echo $__env->renderComponent(); ?>



Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH /Users/jasmin/Desktop/hardik/Info/resources/views/email/notification.blade.php ENDPATH**/ ?>